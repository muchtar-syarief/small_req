########### KTP Converter #############

1. Jalankan program "main.exe"
2. masukkan lokasi folder dari gambar yg akan di konversi
3. tunggu hingga selesai



NOTED:
Hanya melakukan downgrading image dengan ukuran lebih dari 4MB